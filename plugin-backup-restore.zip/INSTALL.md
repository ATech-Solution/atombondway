# Plugin System — Installation Guide

This package contains the Plugins collection + Backup & Restore plugin for Payload CMS 3.x + Next.js 15 projects.

## Quick Install

Copy the folders from this package into your project root (same structure):

```
src/plugins/             → your-project/src/plugins/
src/payload/collections/Plugins.ts → your-project/src/payload/collections/Plugins.ts
src/app/api/plugins/     → your-project/src/app/api/plugins/
backups/                 → your-project/backups/
docs/                    → your-project/docs/
```

## Required changes to existing files

### payload.config.ts

1. Add imports:
   ```typescript
   import { Plugins } from './src/payload/collections/Plugins.ts'
   import { PLUGIN_METADATA } from './src/plugins/backup-restore/index.ts'
   ```

2. Add `Plugins` to `collections` array.

3. Add admin view inside `admin.components`:
   ```typescript
   views: {
     BackupRestore: {
       Component: '@/plugins/backup-restore/BackupView#BackupView',
       path: '/plugins/backup',
     },
   }
   ```

4. Add `seedPlugins` function + `onInit` hook (see `docs/ai-prompt-plugin-system.md` for full code).

### .gitignore

Add:
```
backups/db/*.db
backups/files/*.tar.gz
```

### package.json

Add scripts:
```json
"backup": "node backups/scripts/backup.js",
"restore": "node backups/scripts/restore.js"
```

Add dependency:
```json
"@aws-sdk/client-s3": "^3.0.0"
```

## After copying files

```bash
npm install
npm run generate:types
npm run build
npm run migrate
```

## AI-assisted install

See `docs/ai-prompt-plugin-system.md` for a ready-to-paste AI prompt that automates the full installation.
